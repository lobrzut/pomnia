// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Pomnia
/**
 * Document import pipeline — parse → encrypted vault blobs → index in library.db.
 *
 * Source PDF/DOCX and extracted markdown are stored as AES-256-GCM blobs in the
 * open `.pomnia` vault (same crypto as chat snapshots). Parsing and embedding
 * happen once at import; search reads chunks from library.db only.
 */

import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { basename, extname } from 'node:path'
import {
  applyOcrToDocument,
  buildExtractedMarkdown,
  extractionPathLabel,
  parseDocument,
  runOcr,
  suggestOcr,
} from '@pomnia/doc-parser'
import { log } from '@core/index.js'
// Subpath only — full @pomnia/brain-core entry pulls better-sqlite3 into main.
import { defaultVaultConfig, ensureLibraryDirs } from '@pomnia/brain-core/vault'
import { libraryDocLogicalPath, Vault } from '@core/vault.js'
import { brainCore } from './brainCore.js'
import { brainCoreDataDir } from './brainPaths.js'
import {
  ensureBrainForIndexing,
  indexPendingLibraryDocuments,
  type LibraryIndexProgress,
} from './libraryIndex.js'
import type { DocImportResult } from './docImportTypes.js'

export type { DocImportResult } from './docImportTypes.js'

export async function importDocument(
  vault: Vault,
  vaultDir: string,
  filePath: string,
  onProgress?: (e: LibraryIndexProgress) => void,
  ollamaUrl?: string,
): Promise<DocImportResult> {
  const dataDir = brainCoreDataDir()
  const vaultCfg = defaultVaultConfig(dataDir)
  ensureLibraryDirs(vaultCfg)

  const raw = readFileSync(filePath)
  const contentSha = createHash('sha256').update(raw).digest('hex')
  const sha16 = contentSha.slice(0, 16)
  const baseName = basename(filePath)
  const docId = `${sha16}_${baseName}`

  const already =
    vault.getLibraryDocument(docId) ??
    vault.getLibraryManifest().documents.find((d) => d.contentSha === contentSha)
  if (already) {
    const logicalPath = libraryDocLogicalPath(vaultDir, already.id)
    return {
      docId: already.id,
      sourcePath: logicalPath,
      extractedPath: `${logicalPath}/extracted.md`,
      format: already.format,
      pages: already.pages,
      chunks: 0,
      sparse: !!already.sparse,
      extractionPath: already.extractionPath,
      suggestOcr: false,
      indexed: !!already.indexedAt && !already.pendingIndex,
      pendingIndex: !!already.pendingIndex,
      brainRunning: brainCore.status().running,
      brainAutoStarted: false,
      encrypted: true,
      skipped: true,
    }
  }

  onProgress?.({ phase: 'parse', done: 0, total: 1, detail: baseName })
  let parsed = await parseDocument(filePath)
  onProgress?.({ phase: 'parse', done: 1, total: 1, detail: extractionPathLabel(parsed) })

  /*
   * A scan gets read here, not after somebody notices a suggestion.
   *
   * Mini has done this since the day a 147-page book arrived as 3.6 kB of YAML
   * frontmatter and was counted as one note. The full app kept the older
   * arrangement — import the scan, store it with no text, index that, and offer
   * an OCR button the user had to find — so the same book through the same
   * product became either knowledge or an empty document depending on which
   * build opened it. The empty one was indexed, and answering.
   *
   * The on-demand path in docOcr.ts stays, for a document already in the
   * library from before this.
   */
  if (parsed.meta.sparse && parsed.format === 'pdf') {
    try {
      onProgress?.({ phase: 'ocr', done: 0, total: parsed.meta.pageCount, detail: 'tesseract…' })
      const ocr = await runOcr(filePath, {
        prefer: 'tesseract',
        // The whole document. Sampling three pages and indexing the result as
        // the book is how a memory answers questions it has no business
        // answering.
        maxPages: parsed.meta.pageCount,
        onProgress: (ev) =>
          onProgress?.({ phase: 'ocr', done: ev.done, total: ev.total, detail: baseName }),
      })
      if (ocr.method !== 'none' && ocr.pages.length > 0) {
        parsed = applyOcrToDocument(parsed, ocr)
      }
    } catch (e) {
      // A failed OCR leaves the sparse document exactly as it was, which is
      // what the older behaviour produced anyway. It must not lose the import.
      log.warn('ocr failed during import of', baseName, e)
    }
  }

  const md = buildExtractedMarkdown(parsed.markdown, {
    source_file: baseName,
    source_sha256: sha16,
    format: parsed.format,
    extraction_tier: parsed.meta.tier,
    extraction_sparse: parsed.meta.sparse,
    extraction_path: extractionPathLabel(parsed),
    pages: parsed.meta.pageCount,
    imported_at: new Date().toISOString(),
    imported_via: 'pomnia',
  })

  onProgress?.({ phase: 'encrypt', done: 0, total: 2, detail: 'vault…' })
  await vault.addLibraryDocument(
    {
      id: docId,
      originalName: baseName,
      format: parsed.format,
      contentSha,
      pages: parsed.meta.pageCount,
      sparse: parsed.meta.sparse,
      extractionPath: extractionPathLabel(parsed),
      importedAt: new Date().toISOString(),
      pendingIndex: true,
    },
    raw,
    Buffer.from(md, 'utf8'),
  )
  onProgress?.({ phase: 'encrypt', done: 2, total: 2 })

  const logicalPath = libraryDocLogicalPath(vaultDir, docId)

  let brainRunning = brainCore.status().running
  let brainAutoStarted = false
  let chunks = 0
  let indexed = false
  let indexError: string | undefined

  if (!brainRunning) {
    const ensured = await ensureBrainForIndexing(ollamaUrl, onProgress, vaultDir)
    brainRunning = ensured.running
    brainAutoStarted = ensured.autoStarted
    if (!brainRunning) indexError = ensured.error
  }

  if (brainRunning) {
    onProgress?.({ phase: 'index', done: 0, total: parsed.pages.length, detail: 'embedding…' })
    const stats = (await brainCore.indexDocument({
      path: logicalPath,
      name: baseName,
      pages: parsed.pages,
    })) as { chunks?: number }
    chunks = stats?.chunks ?? 0
    indexed = true
    onProgress?.({ phase: 'index', done: parsed.pages.length, total: parsed.pages.length })
    await vault.markLibraryDocIndexed(docId)

    // Flush any older docs that were queued while Brain was offline.
    await indexPendingLibraryDocuments(vault, vaultDir, {
      skipDocId: docId,
      ollamaUrl,
      onProgress,
    })
  }

  return {
    docId,
    sourcePath: logicalPath,
    extractedPath: `${logicalPath}/extracted.md`,
    format: parsed.format,
    pages: parsed.meta.pageCount,
    chunks,
    sparse: parsed.meta.sparse,
    extractionPath: extractionPathLabel(parsed),
    suggestOcr: suggestOcr(parsed),
    indexed,
    pendingIndex: !indexed,
    brainRunning,
    brainAutoStarted,
    indexError,
    encrypted: true,
  }
}

/** File extensions accepted by the document import picker. */
export const DOC_IMPORT_EXTENSIONS = ['pdf', 'docx', 'md', 'txt', 'epub']

export function isDocImportPath(p: string): boolean {
  return DOC_IMPORT_EXTENSIONS.includes(extname(p).slice(1).toLowerCase())
}
