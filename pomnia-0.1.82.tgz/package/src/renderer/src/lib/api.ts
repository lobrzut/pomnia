// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Pomnia
import { DEFAULT_HANDSHAKE_PHRASE } from '@core/handshakePhrase'
import type {
  RemotePrompt,
  RemoteSkillRow,
  RemoteSkillsSummary,
} from '@core/brain/remoteSkills'
import type {
  ActivityState,
  LastActivityReplay,
  BackupProgressEvent,
  BrainHit,
  BrainRunResult,
  BrainPing,
  BrainProgressEvent,
  DocImportProgressEvent,
  DocImportResult,
  DocOcrResult,
  LibraryDocListItem,
  LibraryDocRemoveResult,
  ImportChatPreview,
  QuarantineBucket,
  QuarantineNoteMeta,
  BrainStateInfo,
  BrainStatus,
  ClientId,
  EmbeddedBrainStatus,
  ClientStatus,
  Conversation,
  ConversationMeta,
  DetectedSource,
  OllamaPullEvent,
  Snapshot,
  Snippet,
  SourceId,
  TextHit,
  VaultStatus,
  SkillsListResult,
  PromptsListResult,
} from './types'

export type ProfilePreviewStatus = 'ok' | 'vault_locked' | 'brain_down' | 'no_knowledge'

export interface ProfilePreviewResult {
  status: ProfilePreviewStatus
  summary?: string
  source?: 'ollama' | 'fallback'
  /** Raw vault USER.md for editing when vault is open. */
  userMd?: string
}

export type ProfilePreviewSaveResult =
  | { ok: true; path: string; chars: number }
  | { ok: false; error: 'vault_locked' | 'too_long' | 'write_failed'; detail?: string; maxChars?: number }

/** The bridge exposed by preload as window.pomnia. */
export interface PomniaBridge {
  platform: string
  getPathForFile(file: File): string
  scan(): Promise<DetectedSource[]>
  vaultStatus(): Promise<VaultStatus>
  pickDirectory(): Promise<string | null>
  pickFile(): Promise<string | null>
  pickDocFile(): Promise<string | null>
  createVault(path: string, name: string, passphrase: string): Promise<VaultStatus>
  openVault(path: string, passphrase: string): Promise<VaultStatus>
  lockVault(): Promise<void>
  listSnapshots(): Promise<Snapshot[]>
  backup(sources: SourceId[], note?: string): Promise<Snapshot[]>
  onBackupProgress(cb: (e: BackupProgressEvent) => void): () => void
  verify(): Promise<{ ok: boolean; checked: number; errors: string[] }>
  vaultConversations(): Promise<ConversationMeta[]>
  vaultConversation(snapshotId: string, id: string): Promise<Conversation | null>
  vaultSearchText(query: string): Promise<TextHit[]>
  importToVault(path: string): Promise<{
    sealed: number
    added?: number
    updated?: number
    skipped?: number
    sources: { source: string; count: number }[]
  }>
  importPreview(path: string): Promise<ImportChatPreview>
  distilledQuarantineList(): Promise<{ review: QuarantineNoteMeta[]; weak: QuarantineNoteMeta[] }>
  distilledQuarantineRead(bucket: QuarantineBucket, name: string): Promise<{ content: string }>
  distilledQuarantinePromote(bucket: QuarantineBucket, name: string): Promise<{ name: string; path: string }>
  distilledQuarantineDelete(
    bucket: QuarantineBucket,
    name: string,
  ): Promise<{ name: string; bucket: QuarantineBucket }>
  distilledQuarantineDeleteReview(names: string[]): Promise<{ deleted: string[]; failed: string[] }>
  docImport(path?: string, ollamaUrl?: string): Promise<DocImportResult | null>
  docOcr(docId: string, ollamaUrl?: string): Promise<DocOcrResult>
  docList(): Promise<LibraryDocListItem[]>
  docRemove(docId: string): Promise<LibraryDocRemoveResult>
  brainExport(snapshotId: string, outDir: string): Promise<{ count: number; dir: string }>
  skillsList(): Promise<SkillsListResult>
  /** The prompt library in this vault — the local sibling of skillsList. */
  promptsList(): Promise<PromptsListResult>
  promptsCreate(name: string): Promise<{ ok: true; path: string } | { ok: false; error: string }>
  promptsDelete(name: string): Promise<{ ok: boolean; error?: string }>
  skillsDelete(filePath: string): Promise<{ ok: boolean; error?: string }>
  skillsReveal(target: string, mode?: 'file' | 'folder'): Promise<{ ok: boolean; error: string | null }>
  /** Open the app install folder (optional AV last-resort paths). */
  revealInstallDir(): Promise<{ ok: boolean; path: string; error: string | null }>
  brainStatus(ollamaUrl?: string): Promise<BrainStatus>
  brainRun(opts: {
    sources: SourceId[]
    limit?: number
    model?: string
    ollamaUrl?: string
    importPath?: string
    pendingOnly?: boolean
    autoDeploy?: boolean
    deployUrl?: string
    deployTarget?: string
    deployToken?: string
    reindex?: boolean
  }): Promise<BrainRunResult>
  brainRunCancel(): Promise<{ ok: boolean }>
  brainState(): Promise<BrainStateInfo>
  brainCoreStatus(): Promise<EmbeddedBrainStatus>
  brainCoreStart(ollamaUrl?: string): Promise<EmbeddedBrainStatus>
  brainCoreStop(): Promise<EmbeddedBrainStatus>
  brainCoreReindex(): Promise<{ stats: { files: number; chunks: number; empty: number; prunedFiles: number } }>
  /** Abort the index pass in flight; the pending reindex rejects with `reindex aborted`. */
  brainCoreCancelIndex(): Promise<EmbeddedBrainStatus>
  vaultHealth(): Promise<{
    level: string
    code: string
    titlePl: string
    detailPl: string
    distilledNotes: number
    sessionNotes: number
    indexChunks: number | null
    action?: string
  }>
  doctorRun(opts?: { distillModel?: string; ollamaUrl?: string }): Promise<{
    checks: Array<{
      id: string
      level: 'OK' | 'WARN' | 'FAIL'
      message: string
      action?: string
      data?: Record<string, unknown>
    }>
    ok: number
    warn: number
    fail: number
    exitCode: 0 | 1
    generatedAt: string
  }>
  onBrainCoreEvent(cb: (e: { type: string; file?: string; done?: number; total?: number }) => void): () => void
  onBrainProgress(cb: (e: BrainProgressEvent) => void): () => void
  brainSearch(query: string, ollamaUrl?: string): Promise<BrainHit[]>
  ollamaPull(model: string, ollamaUrl?: string): Promise<{ ok: boolean }>
  ollamaPullCancel(): Promise<{ ok: boolean }>
  onOllamaPullProgress(cb: (e: OllamaPullEvent) => void): () => void
  onDocImportProgress(cb: (e: DocImportProgressEvent) => void): () => void
  onLibraryIndexComplete(cb: (e: { indexed: number; chunks: number; errors: string[] }) => void): () => void
  activityGet(): Promise<ActivityState>
  activityLastReplay(): Promise<LastActivityReplay | null>
  mcpActivityWatch(active: boolean): Promise<{ ok: boolean }>
  onActivityUpdate(cb: (e: ActivityState) => void): () => void
  onActivityIdle(cb: () => void): () => void
  brainDeploy(opts: {
    to: 'filesystem' | 'dashboard'
    target?: string
    url?: string
    reindex?: boolean
    token?: string
    sources?: SourceId[]
    /** `ok` is false when any sub-step failed — deploy can partly succeed. */
  }): Promise<{ detail: string; ok: boolean; problems: string[] }>
  connectStatus(
    brainUrl?: string,
    token?: string,
    target?: 'embedded' | 'remote',
  ): Promise<{ clients: ClientStatus[]; brain: BrainPing }>
  connectSnippet(
    clientId: ClientId,
    brainUrl: string,
    token?: string,
    target?: 'embedded' | 'remote',
    brainMode?: boolean,
    remoteHub?: 'brain-core' | 'legacy-hub',
  ): Promise<Snippet>
  connectWriteBrief(clientId: ClientId): Promise<
    | { ok: true; path: string; bytes: number; handshakePath?: string; agentsPath?: string }
    | { ok: false; error: string; detail?: string; path?: string }
  >
  /** Agents the server has actually seen connect. Empty list = none yet. */
  mcpSeenClients(
    brainUrl: string,
    token?: string,
  ): Promise<{
    supported: boolean
    clients: { name: string; version?: string; firstSeen: number; lastSeen: number; connects: number }[]
  }>
  appDataLocations(): Promise<{
    platform: 'win32' | 'darwin' | 'linux'
    installForm: 'appimage' | 'deb' | 'nsis' | 'dmg' | 'dev' | 'unknown'
    userDataDir: string
    brainCoreDataDir: string
    libraryDbPath: string
    logsDir: string
    defaultVaultExample: string
    vaultPath: string | null
    indexIsPlaintext: true
  }>
  openUserData(): Promise<string>
  openBrainData(): Promise<string>
  vaultReplicaState(): Promise<{
    url: string
    hasToken: boolean
    autoSync: boolean
    last: {
      at: string
      ok: boolean
      uploaded: number
      unchanged: number
      failed: number
      error?: string
    } | null
  }>
  vaultReplicaConfig(patch: {
    url?: string
    token?: string
    autoSync?: boolean
  }): Promise<{ url: string; hasToken: boolean; autoSync: boolean }>
  vaultSyncToReplica(
    target: string,
    token?: string,
  ): Promise<{
    unchanged: number
    uploaded: number
    failed: Array<{ path: string; reason: string }>
    skipped: Array<{ path: string; reason: string }>
    extraOnReplica: string[]
    bytesUploaded: number
  }>
  /**
   * Hand the server one token and let it say what it is. An admin token is
   * kept in main and never comes back; the agent token minted from it does,
   * because the page needs it for the snippet.
   */
  /**
   * Notes parsed and waiting to be sent, with the size and — only once an
   * upload has actually been timed — how long the next one should take.
   */
  appUpdateCheck(): Promise<{
    current: string
    checkedAt: string
    state: 'current' | 'available' | 'unreachable'
    latest?: string | null
    releaseUrl?: string
    detail?: string
  }>
  /**
   * Skills and prompts that live on the server. The admin token never leaves
   * main; the renderer sends a name or a path and gets text back.
   *
   * The list arrives as a summary — own skills in full, cli as categories with
   * counts — because the full catalogue is over a thousand entries. Pick a
   * category or type a query to see the skills themselves.
   */
  skillsRemoteList(): Promise<RemoteSkillsSummary | { error: string; detail: string }>
  skillsRemoteListIn(opts: {
    category?: string
    query?: string
    offset?: number
  }): Promise<
    { rows: RemoteSkillRow[]; total: number; nextOffset?: number } | { error: string; detail: string }
  >
  skillsRemoteRead(path: string): Promise<{ path: string; content: string } | { error: string; detail: string }>
  skillsRemoteWrite(
    path: string,
    content: string,
  ): Promise<{ path: string; unchanged: boolean } | { error: string; detail: string }>
  skillsRemoteDelete(path: string): Promise<{ path: string } | { error: string; detail: string }>
  promptsRemoteDelete(name: string): Promise<{ name: string } | { error: string; detail: string }>
  promptsRemoteList(): Promise<{ prompts: RemotePrompt[] } | { error: string; detail: string }>
  promptsRemoteRead(name: string): Promise<{ name: string; content: string } | { error: string; detail: string }>
  promptsRemoteWrite(
    name: string,
    content: string,
  ): Promise<
    { name: string; unchanged: boolean; created: boolean } | { error: string; detail: string }
  >
  miniIngestState(): Promise<{
    staged: number
    bytes: number
    etaSeconds: number | null
    rateSamples: number
  }>
  miniIngestPick(): Promise<string[]>
  miniIngestFiles(
    paths: string[],
    opts?: { ollamaUrl?: string; model?: string; ocr?: boolean; ocrPages?: number },
  ): Promise<{
    files: { file: string; kind: 'document' | 'export'; notes: number; detail: string; error?: string }[]
    staged: number
    rawTranscripts: boolean
  }>
  miniIngestPush(): Promise<
    | { ok: true; result: { uploaded: number; unchanged: number; failed: unknown[] } }
    | { ok: false; reason: string; detail: string }
  >
  miniIngestClear(): Promise<{ staged: number }>
  /** Fires while OCR runs; returns an unsubscribe. */
  onMiniIngestProgress(
    cb: (ev: { file: string; phase: 'ocr'; done: number; total: number }) => void,
  ): () => void
  connectTokenAdopt(
    brainUrl: string,
    token: string,
  ): Promise<{ role: 'admin' | 'not-admin' | 'unreachable'; detail: string; agentToken: string }>
  /**
   * Whether the *stored* admin token is still accepted, asked of the server.
   * `hasToken` only says one was saved, which stays true after it is revoked.
   */
  connectTokenStatus(): Promise<{
    state: 'admin' | 'not-admin' | 'unreachable' | 'missing' | 'no-target'
    detail: string
  }>
  connectMcpTokenCreate(
    brainUrl: string,
    name: string,
    adminToken?: string,
  ): Promise<{ name: string; token: string; created: string }>
  appSettings(): Promise<{
    minimizeToTray: boolean
    closeToTray: boolean
    ollamaUrl?: string
    brainMcpUrl?: string
    brainDeployUrl?: string
    brainTarget?: 'embedded' | 'remote'
    connectToken?: string
    embeddedBrainAutoStart?: boolean
    onboarded?: boolean
    floatingMonitorOnMinimize?: boolean
    openAtLogin?: boolean
    colorScheme?: 'mint' | 'iris' | 'glass'
    uiLocale?: 'pl' | 'en'
    handshakePhrase?: string
    handshakeEnabled?: boolean
    autoCheckpointEnabled?: boolean
  }>
  appSettingsSet(patch: {
    minimizeToTray?: boolean
    closeToTray?: boolean
    ollamaUrl?: string
    brainMcpUrl?: string
    brainDeployUrl?: string
    brainTarget?: 'embedded' | 'remote'
    connectToken?: string
    embeddedBrainAutoStart?: boolean
    onboarded?: boolean
    floatingMonitorOnMinimize?: boolean
    openAtLogin?: boolean
    colorScheme?: 'mint' | 'iris' | 'glass'
    uiLocale?: 'pl' | 'en'
    handshakePhrase?: string
    handshakeEnabled?: boolean
    autoCheckpointEnabled?: boolean
  }): Promise<{
    minimizeToTray: boolean
    closeToTray: boolean
    ollamaUrl?: string
    brainMcpUrl?: string
    brainDeployUrl?: string
    brainTarget?: 'embedded' | 'remote'
    connectToken?: string
    embeddedBrainAutoStart?: boolean
    onboarded?: boolean
    floatingMonitorOnMinimize?: boolean
    openAtLogin?: boolean
    colorScheme?: 'mint' | 'iris' | 'glass'
    uiLocale?: 'pl' | 'en'
    handshakePhrase?: string
    handshakeEnabled?: boolean
    autoCheckpointEnabled?: boolean
  }>
  onColorScheme(cb: (scheme: 'mint' | 'iris' | 'glass') => void): () => void
  onUiLocale(cb: (locale: 'pl' | 'en') => void): () => void
  openLogs(): Promise<string>
  appVersion(): Promise<{ version: string; identity: string }>
  floatingMonitorHide(): Promise<{ visible: boolean }>
  floatingMonitorOpenMain(): Promise<{ ok: boolean }>
  floatingMonitorGetAlwaysOnTop(): Promise<{ alwaysOnTop: boolean }>
  floatingMonitorSetAlwaysOnTop(on: boolean): Promise<{ alwaysOnTop: boolean }>
  onHandshakePhrase(cb: (e: { phrase: string; enabled?: boolean }) => void): () => void
  profilePreviewShow(): Promise<{ visible: boolean }>
  profilePreviewHide(): Promise<{ visible: boolean }>
  profilePreviewLoad(): Promise<ProfilePreviewResult>
  onProfilePreviewProgress(
    cb: (e: { phase: 'user_md' | 'notes' | 'search' | 'summarize' | 'done'; pct: number }) => void,
  ): () => void
  profilePreviewSave(content: string): Promise<ProfilePreviewSaveResult>
  onAppToast(cb: (t: { kind: 'info' | 'success' | 'warn' | 'error'; title: string; detail?: string }) => void): () => void
  onAppNavigate(cb: (route: string) => void): () => void
  minimize(): void
  toggleMaximize(): void
  close(): void
}

/* ── Mock bridge for browser preview (no Electron) ──────────────────────── */
const mockPullListeners = new Set<(e: OllamaPullEvent) => void>()
let mockPullCancelled = false
let mockHandshakePhrase = DEFAULT_HANDSHAKE_PHRASE
let mockHandshakeEnabled = true
let mockAutoCheckpointEnabled = true
const mockEmbedded: EmbeddedBrainStatus = {
  running: false,
  starting: false,
  indexing: false,
  url: null,
  dataDir: 'C:/Users/…/Pomnia/brain-core-data',
  lastError: null
}
// Mutable so "distill backlog" is demoable: brainRun drains the pending count.
const mockBrainState: BrainStateInfo = {
  total: 59,
  distilled: 38,
  pending: 21,
  perSource: [
    { source: 'claude-code', label: 'Claude Code', total: 38, pending: 12 },
    { source: 'cursor', label: 'Cursor', total: 21, pending: 9 }
  ],
  lastRun: new Date(Date.now() - 26 * 3600e3).toISOString()
}

function mockBridge(): PomniaBridge {
  const demoSources: DetectedSource[] = [
    { id: 'claude-code', label: 'Claude Code', strategy: 'hybrid', installed: true, root: '~/.claude', os: 'win32', sizeBytes: 7.2e6, conversations: 38, notes: ['JSONL transcripts per session'] },
    { id: 'cursor', label: 'Cursor', strategy: 'hybrid', installed: true, root: '~/AppData/Roaming/Cursor/User', os: 'win32', sizeBytes: 1.6e7, conversations: 21, notes: ['Chats live in state.vscdb (SQLite)'] },
    { id: 'claude-desktop', label: 'Claude Desktop', strategy: 'snapshot', installed: true, root: '~/AppData/Roaming/Claude', os: 'win32', sizeBytes: 8.5e6, notes: ['Mostly cloud-synced; local config captured'] },
    { id: 'antigravity', label: 'Antigravity', strategy: 'hybrid', installed: true, root: '~/AppData/Roaming/Antigravity', os: 'win32', sizeBytes: 7.6e3, conversations: 7, notes: ['Chats in ~/.gemini/antigravity/brain/*/transcript.jsonl'] },
    { id: 'vscode', label: 'VS Code', strategy: 'snapshot', installed: true, root: '~/AppData/Roaming/Code/User', os: 'win32', sizeBytes: 3.4e5 }
  ]
  let status: VaultStatus = {
    open: false,
    snapshots: 0,
    skillsCount: 0,
    skillsOwnCount: 0,
    skillsImportedCount: 0,
    distilledNotes: 0,
  }
  let snaps: Snapshot[] = []
  const mkSnap = (id: SourceId, label: string, n: number): Snapshot => ({
    id: crypto.randomUUID(),
    createdAt: new Date(Date.now() - Math.random() * 6e8).toISOString(),
    source: { id, label, strategy: 'hybrid', root: '~', os: 'win32' },
    stats: { conversations: n, messages: n * 22, files: n * 3, bytes: n * 1.2e6 },
    origin: { host: 'WIN-DESK', user: 'Alice', home: 'C:\\Users\\Alice' }
  })
  return {
    platform: 'browser',
    getPathForFile(file: File) {
      const legacy = (file as File & { path?: string }).path
      return legacy ?? `C:/Users/Alice/Downloads/${file.name}`
    },
    async scan() {
      await new Promise((r) => setTimeout(r, 600))
      return demoSources
    },
    async vaultStatus() {
      return status
    },
    async pickDirectory() {
      return 'C:/Users/Alice/Pomnia.pomnia'
    },
    async pickFile() {
      return 'C:/Users/Alice/Downloads/claude-export.zip'
    },
    async pickDocFile() {
      return 'C:/Users/Alice/Downloads/report.pdf'
    },
    async createVault(path, name) {
      status = {
        open: true,
        path,
        name,
        snapshots: 0,
        skillsCount: 3,
        skillsOwnCount: 2,
        skillsImportedCount: 1,
        distilledNotes: 12,
        knowledgePath: path,
      }
      return status
    },
    async openVault(path, _pass) {
      snaps = [mkSnap('claude-code', 'Claude Code', 38), mkSnap('cursor', 'Cursor', 21)]
      status = {
        open: true,
        path,
        name: 'Demo Vault',
        snapshots: snaps.length,
        skillsCount: 5,
        skillsOwnCount: 2,
        skillsImportedCount: 3,
        distilledNotes: 24,
        knowledgePath: path,
      }
      return status
    },
    async lockVault() {
      status = {
        open: false,
        snapshots: 0,
        skillsCount: 0,
        skillsOwnCount: 0,
        skillsImportedCount: 0,
        distilledNotes: 0,
      }
      snaps = []
    },
    async listSnapshots() {
      return snaps
    },
    async backup(sources) {
      await new Promise((r) => setTimeout(r, 1200))
      const made = sources.map((s) => mkSnap(s, demoSources.find((d) => d.id === s)?.label ?? s, 10))
      snaps = [...made, ...snaps]
      status = { ...status, snapshots: snaps.length }
      return made
    },
    onBackupProgress() {
      return () => {}
    },
    async verify() {
      return { ok: true, checked: 132, errors: [] }
    },
    async vaultConversations() {
      const demo: { id: string; source: SourceId; title: string; messages: number; updatedAt: string }[] = [
        { id: 'd1', source: 'claude-code', title: 'Designing the Pomnia vault', messages: 42, updatedAt: '2026-06-10T20:00:00Z' },
        { id: 'd2', source: 'cursor', title: 'MikroTik WireGuard killswitch', messages: 18, updatedAt: '2026-06-09T12:00:00Z' },
        { id: 'd3', source: 'claude-code', title: 'Pine Script non-repaint ATR stop', messages: 26, updatedAt: '2026-06-07T09:00:00Z' },
        { id: 'd4', source: 'cursor', title: 'Bug bounty IDOR methodology', messages: 31, updatedAt: '2026-06-05T18:00:00Z' }
      ]
      return demo.map((d) => ({ ...d, snapshotId: 'snap' }))
    },
    async vaultConversation(_sid, id) {
      return {
        id,
        source: 'claude-code',
        title: 'Designing the Pomnia vault',
        messages: [
          { role: 'user', text: 'How should the vault dedupe files across snapshots?' },
          { role: 'assistant', text: 'Use content-addressed blobs keyed by SHA-256: identical files store once, snapshots reference the hash.' },
          { role: 'user', text: 'And cross-platform restore?' },
          { role: 'assistant', text: 'Remap the home dir + Claude Code project-dir encoding from the origin OS to the target OS.' }
        ]
      } as Conversation
    },
    async importToVault() {
      await new Promise((r) => setTimeout(r, 700))
      return {
        sealed: 42,
        added: 42,
        updated: 0,
        skipped: 0,
        sources: [
          { source: 'claude-ai', count: 38 },
          { source: 'chatgpt', count: 4 },
        ],
      }
    },
    async importPreview(path: string) {
      await new Promise((r) => setTimeout(r, 400))
      return {
        path,
        fileName: path.split(/[\\/]/).pop() ?? 'export.zip',
        conversationCount: 42,
        messageCount: 860,
        sources: [
          { source: 'claude-ai', count: 38 },
          { source: 'chatgpt', count: 4 },
        ],
        titles: ['Designing the vault', 'MCP handshake', 'Import confirm', 'Skills sync', 'Distill backlog'],
        hasGeneric: false,
        added: 42,
        updated: 0,
        skipped: 0,
      }
    },
    async distilledQuarantineList() {
      return {
        review: [{ bucket: 'review' as const, name: 'stub-note.md', mtimeMs: Date.now(), sizeBytes: 120 }],
        weak: [{ bucket: 'weak' as const, name: 'thin-note.md', mtimeMs: Date.now() - 1e6, sizeBytes: 400 }],
      }
    },
    async distilledQuarantineRead(_bucket, name) {
      return { content: `---\nquality: garbage\n---\n\n# ${name}\n\nSample quarantine note body.\n` }
    },
    async distilledQuarantinePromote(bucket, name) {
      return { name, path: `C:/Vault/distilled/${name}` }
    },
    async distilledQuarantineDelete(bucket, name) {
      return { name, bucket }
    },
    async distilledQuarantineDeleteReview(names) {
      return { deleted: [...names], failed: [] }
    },
    async docImport() {
      await new Promise((r) => setTimeout(r, 900))
      return {
        docId: 'abc_report.pdf',
        sourcePath: 'C:/Vault.pomnia/library/abc_report.pdf',
        extractedPath: 'C:/Vault.pomnia/library/abc_report.pdf/extracted.md',
        format: 'pdf',
        pages: 12,
        chunks: 18,
        sparse: false,
        extractionPath: 'unpdf',
        suggestOcr: false,
        indexed: true,
        pendingIndex: false,
        brainRunning: true,
        brainAutoStarted: false,
        encrypted: true,
      }
    },
    async docOcr(docId: string) {
      await new Promise((r) => setTimeout(r, 1200))
      return {
        docId,
        sourcePath: 'C:/Vault.pomnia/library/abc_scan.pdf',
        extractedPath: 'C:/Vault.pomnia/library/abc_scan.pdf/extracted.md',
        format: 'pdf',
        pages: 3,
        chunks: 4,
        sparse: false,
        extractionPath: 'unpdf+tesseract',
        suggestOcr: false,
        indexed: true,
        pendingIndex: false,
        brainRunning: true,
        brainAutoStarted: false,
        encrypted: true,
        ocrMethod: 'tesseract' as const,
        ocrPages: 3,
      }
    },
    async docList() {
      return [
        {
          id: 'abc_report.pdf',
          originalName: 'report.pdf',
          format: 'pdf',
          pages: 12,
          importedAt: new Date().toISOString(),
          pendingIndex: false,
          indexedAt: new Date().toISOString(),
          sourceBytes: 12000,
          extractedBytes: 4000,
        },
      ]
    },
    async docRemove(docId: string) {
      return {
        id: docId,
        originalName: 'report.pdf',
        removedBlobs: ['aaa', 'bbb'],
        keptBlobs: [],
        chunksRemoved: 0,
      }
    },
    async vaultSearchText(query) {
      return [
        { snapshotId: 'snap', id: 'd2', source: 'cursor', title: 'MikroTik WireGuard killswitch', snippet: `…${query}… routing-mark + blackhole route on RouterOS 7…`, matches: 3 },
        { snapshotId: 'snap', id: 'd1', source: 'claude-code', title: 'Designing the Pomnia vault', snippet: `…${query}… content-addressed dedup…`, matches: 1 }
      ]
    },
    async brainExport(_id, dir) {
      return { count: 38, dir }
    },
    async promptsList() {
      return {
        promptsRoot: 'C:/Vault/prompts',
        prompts: [
          {
            name: 'zglos-blad',
            description: 'Zamień luźne objawy w zgłoszenie',
            arguments: [
              { name: 'objaw', required: true },
              { name: 'kiedy', required: false },
            ],
            path: 'C:/Vault/prompts/zglos-blad.md',
            folderPath: 'C:/Vault/prompts',
            sizeBytes: 480,
            mtimeMs: Date.now() - 3600e3,
          },
        ],
      }
    },
    async promptsCreate(name: string) {
      return { ok: true as const, path: `C:/Vault/prompts/${name}.md` }
    },
    async promptsDelete() {
      return { ok: true }
    },
    async skillsDelete() {
      return { ok: true }
    },
    async skillsList() {
      return {
        skillsRoot: 'C:/Vault/skills',
        own: [
          {
            kind: 'own' as const,
            name: 'think-for-me',
            description: 'Structured decision helper when the user is stuck.',
            path: 'C:/Vault/skills/brain/think-for-me.md',
            folderPath: 'C:/Vault/skills/brain',
            sizeBytes: 3452,
            mtimeMs: Date.now() - 86400e3,
          },
          {
            kind: 'own' as const,
            name: 'inbox-process',
            description: 'Triage vault inbox notes.',
            path: 'C:/Vault/skills/brain/inbox-process.md',
            folderPath: 'C:/Vault/skills/brain',
            sizeBytes: 671,
            mtimeMs: Date.now() - 172800e3,
          },
        ],
        imported: [
          {
            kind: 'imported' as const,
            name: '09-web-security',
            description: 'Web hacking / bug bounty expertise',
            path: 'C:/Vault/skills/cli/09-web-security/SKILL.md',
            folderPath: 'C:/Vault/skills/cli/09-web-security',
            sizeBytes: 4200,
            mtimeMs: Date.now() - 3600e3,
          },
        ],
      }
    },
    async skillsReveal() {
      return { ok: true, error: null }
    },
    async revealInstallDir() {
      return { ok: true, path: '%LOCALAPPDATA%\\Programs\\Pomnia', error: null }
    },
    async brainStatus() {
      return {
        reachable: true,
        baseUrl: 'http://localhost:11434',
        chatModel: 'llama3.1:8b',
        embedModel: 'nomic-embed-text',
        models: ['llama3.1:8b', 'nomic-embed-text', 'qwen2.5:14b']
      }
    },
    async brainRun() {
      await new Promise((r) => setTimeout(r, 1400))
      // Drain the mock backlog so the Brain state panel reacts like the real app.
      mockBrainState.distilled = mockBrainState.total
      mockBrainState.pending = 0
      mockBrainState.perSource.forEach((p) => (p.pending = 0))
      mockBrainState.lastRun = new Date().toISOString()
      return { notesDir: 'C:/…/brain-notes', notes: 38, stubs: 4, garbage: 3, skipped: 7, failed: 0, chunks: 121, dim: 768 }
    },
    async brainRunCancel() {
      return { ok: true }
    },
    async brainState() {
      return { ...mockBrainState, perSource: mockBrainState.perSource.map((p) => ({ ...p })) }
    },
    async brainCoreStatus() {
      return { ...mockEmbedded }
    },
    async brainCoreStart() {
      mockEmbedded.starting = true
      await new Promise((r) => setTimeout(r, 900))
      Object.assign(mockEmbedded, { running: true, starting: false, url: 'http://127.0.0.1:7862/mcp', lastError: null })
      return { ...mockEmbedded }
    },
    async brainCoreStop() {
      Object.assign(mockEmbedded, { running: false, indexing: false, url: null })
      return { ...mockEmbedded }
    },
    async brainCoreReindex() {
      mockEmbedded.indexing = true
      await new Promise((r) => setTimeout(r, 1200))
      mockEmbedded.indexing = false
      return { stats: { files: 38, chunks: 121, empty: 2, prunedFiles: 1 } }
    },
    async brainCoreCancelIndex() {
      mockEmbedded.indexing = false
      return { ...mockEmbedded }
    },
    async vaultHealth() {
      return {
        level: 'ok',
        code: 'ok',
        titlePl: 'Vault i indeks wyglądają spójnie',
        detailPl: 'mock',
        distilledNotes: 38,
        sessionNotes: 4,
        indexChunks: 121,
        action: 'none',
      }
    },
    async doctorRun() {
      return {
        checks: [
          { id: 'build', level: 'OK' as const, message: 'build 0.0.0 · mock · 1970-01-01 00:00' },
          {
            id: 'vault',
            level: 'OK' as const,
            message: 'vault mock · open · 10 files · 1 KB · distilled=8 _weak=1 _review=1',
          },
        ],
        ok: 2,
        warn: 0,
        fail: 0,
        exitCode: 0 as const,
        generatedAt: new Date().toISOString(),
      }
    },
    onBrainCoreEvent() {
      return () => {}
    },
    onBrainProgress() {
      return () => {}
    },
    async brainSearch(query) {
      return [
        { score: 0.82, source: 'claude-code', notePath: 'pomnia-design.md', text: `Match for "${query}": content-addressed blobs keyed by SHA-256, dedup identical files…` },
        { score: 0.71, source: 'cursor', notePath: 'mikrotik-wireguard.md', text: 'WireGuard killswitch via routing mark + NordVPN endpoint rotation…' }
      ]
    },
    async brainDeploy() {
      return { detail: 'Deployed 38 notes to Brain vault; reindex triggered.', ok: true, problems: [] }
    },
    async ollamaPull(model) {
      // Simulated download: ~4s of progress events, then success.
      mockPullCancelled = false
      const total = 1_900_000_000
      mockPullListeners.forEach((cb) => cb({ model, status: 'pulling manifest' }))
      for (let i = 1; i <= 20; i++) {
        await new Promise((r) => setTimeout(r, 180))
        if (mockPullCancelled) throw new Error('pull cancelled')
        mockPullListeners.forEach((cb) => cb({ model, status: 'downloading', completed: (total / 20) * i, total }))
      }
      mockPullListeners.forEach((cb) => cb({ model, status: 'success' }))
      return { ok: true }
    },
    async ollamaPullCancel() {
      mockPullCancelled = true
      return { ok: true }
    },
    onOllamaPullProgress(cb) {
      mockPullListeners.add(cb)
      return () => mockPullListeners.delete(cb)
    },
    onDocImportProgress() {
      return () => {}
    },
    onLibraryIndexComplete() {
      return () => {}
    },
    async activityGet() {
      return { kind: 'idle' as const }
    },
    async activityLastReplay() {
      return null
    },
    async mcpActivityWatch() {
      return { ok: true }
    },
    onActivityUpdate() {
      return () => {}
    },
    onActivityIdle() {
      return () => {}
    },
    async connectStatus() {
      await new Promise((r) => setTimeout(r, 500))
      return {
        brain: { url: 'https://brain.example.com:7862/healthz', reachable: true, status: 200, data: { notes: 1731, sessions: 49, library_docs: 42 } },
        clients: [
          { id: 'claude-code', label: 'Claude Code (CLI)', configPath: '~/.claude.json', configExists: true, state: 'wired',
            servers: [
              { key: 'pomnia', present: true, url: 'https://brain.example.com:7862/sse', transport: 'http' },
              { key: 'pomnia-vault', present: true, url: 'https://brain.example.com:7862/servers/brain-vault/sse', transport: 'http' },
              { key: 'pomnia-library', present: true, url: 'https://brain.example.com:7862/servers/brain-library/sse', transport: 'http' }
            ], issues: [] },
          { id: 'cursor', label: 'Cursor', configPath: '~/.cursor/mcp.json', configExists: true, state: 'wired',
            servers: [
              { key: 'pomnia', present: true, url: 'https://brain.example.com:7862/sse' },
              { key: 'pomnia-vault', present: true, url: 'https://brain.example.com:7862/servers/brain-vault/sse' },
              { key: 'pomnia-library', present: true, url: 'https://brain.example.com:7862/servers/brain-library/sse' }
            ], issues: [] },
          { id: 'antigravity', label: 'Antigravity (Google IDE)', configPath: '~/.gemini/antigravity-ide/mcp_config.json', configExists: true, state: 'partial',
            servers: [{ key: 'pomnia', present: true, url: 'https://brain.example.com:7862/mcp', transport: 'streamable-http' }],
            issues: ['pomnia-vault: missing', 'pomnia-library: missing'] },
          { id: 'claude-desktop', label: 'Claude Desktop', configPath: '~/AppData/Roaming/Claude/claude_desktop_config.json', configExists: false, state: 'not_wired', servers: [], issues: ['config file does not exist'] },
          { id: 'vscode', label: 'VS Code (1.103+ native MCP)', configPath: '~/AppData/Roaming/Code/User/mcp.json', configExists: false, state: 'not_wired', servers: [], issues: ['config file does not exist'] },
          { id: 'windsurf', label: 'Windsurf (Codeium)', configPath: '~/AppData/Roaming/Windsurf/User/mcp.json', configExists: false, state: 'not_wired', servers: [], issues: ['config file does not exist'] }
        ]
      } as { clients: ClientStatus[]; brain: BrainPing }
    },
    async connectSnippet(clientId, brainUrl, _token?, _target?, brainMode?, remoteHub?) {
      const legacy = remoteHub === 'legacy-hub'
      const auth = _token ? `, "headers": { "Authorization": "Bearer …" }` : ''
      const servers = legacy
        ? `{\n    "pomnia": { "url": "${brainUrl}/sse"${auth} },\n    "pomnia-vault": { "url": "${brainUrl}/servers/brain-vault/sse"${auth} },\n    "pomnia-library": { "url": "${brainUrl}/servers/brain-library/sse"${auth} }\n  }`
        : `{\n    "pomnia": { "url": "${brainUrl}/mcp"${auth} }\n  }`
      return {
        client: clientId,
        label: clientId,
        filePath: '~/.example/mcp.json',
        mcpKey: 'mcpServers',
        fullFileJson: `{\n  "mcpServers": ${servers}\n}\n`,
        mergeJson: `${servers}\n`,
        instructions: `▶ ${clientId}\n\n1. Open or create the config file.\n2. Paste the snippet.\n3. Restart the client.`,
        restartHint: 'Restart the client to pick up the new config.',
        notes: legacy
          ? 'Mock snippet (browser preview). Legacy hub: pomnia + pomnia-vault + pomnia-library SSE.'
          : 'Mock snippet (browser preview). Remote brain-core: one pomnia → /mcp + Bearer.',
        agentRuleMarkdown: brainMode
          ? '<!-- pomnia-brain-start -->\n# Pomnia (preview)\n<!-- pomnia-brain-end -->\n'
          : undefined,
      }
    },
    async connectWriteBrief(clientId) {
      const path =
        clientId === 'claude-code'
          ? 'C:/Users/Mock/.claude/CLAUDE.md'
          : clientId === 'antigravity'
            ? 'C:/Users/Mock/.gemini/config/GEMINI.md'
            : 'C:/Users/Mock/.cursor/rules/brain.mdc'
      return {
        ok: true as const,
        path,
        bytes: 420,
      }
    },
    async appUpdateCheck() {
      return {
        current: '0.1.54',
        checkedAt: new Date().toISOString(),
        state: 'current' as const,
        latest: '0.1.54',
      }
    },
    async appDataLocations() {
      return {
        platform: 'linux' as const,
        installForm: 'appimage' as const,
        userDataDir: '/home/alice/.config/Pomnia',
        brainCoreDataDir: '/home/alice/.config/Pomnia/brain-core-data',
        libraryDbPath: '/home/alice/.config/Pomnia/brain-core-data/vectordb/library.db',
        logsDir: '/home/alice/.config/Pomnia/logs',
        defaultVaultExample: '/home/alice/Vault',
        vaultPath: '/home/alice/Vault',
        indexIsPlaintext: true as const,
      }
    },
    async openUserData() {
      return '/home/alice/.config/Pomnia'
    },
    async openBrainData() {
      return '/home/alice/.config/Pomnia/brain-core-data'
    },
    async vaultReplicaState() {
      return {
        url: 'https://brain.example.com',
        hasToken: true,
        autoSync: true,
        // The interesting mock is a *failure*: a success tells you nothing
        // about whether the failure path renders.
        last: {
          at: new Date(Date.now() - 40 * 60_000).toISOString(),
          ok: false,
          uploaded: 0,
          unchanged: 0,
          failed: 0,
          error: 'fetch failed',
        },
      }
    },
    async vaultReplicaConfig(patch: { url?: string; token?: string; autoSync?: boolean }) {
      return { url: patch.url ?? '', hasToken: !!patch.token, autoSync: patch.autoSync === true }
    },
    async vaultSyncToReplica() {
      // Browser mock: the interesting shape is "already up to date", because
      // that is what a second run looks like and it must not read as failure.
      return {
        unchanged: 2864,
        uploaded: 0,
        failed: [],
        skipped: [],
        extraOnReplica: [],
        bytesUploaded: 0,
      }
    },
    async mcpSeenClients() {
      // Illustrative: two that introduced themselves, one of them unknown to
      // this app — which is the point of reading the server instead of a list.
      const now = Date.now()
      return {
        supported: true,
        clients: [
          { name: 'claude-code', version: '2.1.0', firstSeen: now - 86_400_000, lastSeen: now - 60_000, connects: 14 },
          { name: 'some-agent-2027', firstSeen: now - 3_600_000, lastSeen: now - 900_000, connects: 2 },
        ],
      }
    },
    async skillsRemoteList() {
      await new Promise((r) => setTimeout(r, 300))
      return {
        own: [
          { path: 'brain/bug-recon.md', kind: 'own' as const, name: 'bug-recon', description: 'Recon przed zgłoszeniem' },
          { path: 'brain/build-our-way.md', kind: 'own' as const, name: 'build-our-way', description: 'Jak tu budujemy' },
        ],
        categories: [
          { category: 'cyber-mukul', count: 817 },
          { category: 'general', count: 199 },
          { category: 'trading', count: 84 },
        ],
        cliCount: 1100,
      }
    },
    async skillsRemoteListIn(opts) {
      await new Promise((r) => setTimeout(r, 250))
      return {
        rows: [
          {
            path: `cli/${opts.category ?? 'general'}/think-for-me/SKILL.md`,
            kind: 'cli' as const,
            name: 'think-for-me',
            category: opts.category,
            description: 'Przykładowy pakiet ekspertyzy.',
          },
        ],
        total: 1,
      }
    },
    async skillsRemoteRead(path) {
      await new Promise((r) => setTimeout(r, 250))
      return { path, content: `# ${path}

Przykładowa treść skilla.` }
    },
    async skillsRemoteWrite(path) {
      await new Promise((r) => setTimeout(r, 400))
      return { path, unchanged: false }
    },
    async skillsRemoteDelete(path: string) {
      await new Promise((r) => setTimeout(r, 250))
      return { path }
    },
    async promptsRemoteDelete(name: string) {
      await new Promise((r) => setTimeout(r, 250))
      return { name }
    },
    async promptsRemoteList() {
      await new Promise((r) => setTimeout(r, 250))
      return {
        prompts: [
          {
            name: 'zglos-blad',
            description: 'Zamień luźne objawy w zgłoszenie',
            arguments: [
              { name: 'objaw', description: 'Co widziałeś', required: true },
              { name: 'kiedy', required: false },
            ],
            size: 480,
          },
        ],
      }
    },
    async promptsRemoteRead(name) {
      await new Promise((r) => setTimeout(r, 200))
      return { name, content: `---
description: Przykład
---
Treść z {{argumentem}}.
` }
    },
    async promptsRemoteWrite(name) {
      await new Promise((r) => setTimeout(r, 350))
      return { name, unchanged: false, created: false }
    },
    async miniIngestState() {
      return { staged: 0, bytes: 0, etaSeconds: null, rateSamples: 0 }
    },
    async miniIngestPick() {
      return ['C:/przyklad/Thinking Fast and Slow.pdf', 'C:/przyklad/chatgpt-export.zip']
    },
    async miniIngestFiles(paths) {
      await new Promise((r) => setTimeout(r, 600))
      return {
        files: paths.map((p, i) => ({
          file: p.split(/[\/]/).pop() ?? p,
          kind: i === 0 ? ('document' as const) : ('export' as const),
          notes: i === 0 ? 1 : 34,
          detail: i === 0 ? 'unpdf, 412 str.' : 'chatgpt',
        })),
        staged: 35,
        rawTranscripts: false,
      }
    },
    async miniIngestPush() {
      await new Promise((r) => setTimeout(r, 800))
      return { ok: true as const, result: { uploaded: 35, unchanged: 0, failed: [] } }
    },
    onMiniIngestProgress() {
      return () => {}
    },
    async miniIngestClear() {
      return { staged: 0 }
    },
    async connectTokenStatus() {
      await new Promise((r) => setTimeout(r, 200))
      return { state: 'admin' as const, detail: 'mock' }
    },
    async connectTokenAdopt(_brainUrl, token) {
      await new Promise((r) => setTimeout(r, 400))
      return token.startsWith('btk_admin')
        ? { role: 'admin' as const, detail: 'mock', agentToken: 'btk_MOCK_agent_from_admin' }
        : { role: 'not-admin' as const, detail: 'mock', agentToken: token }
    },
    async connectMcpTokenCreate(_brainUrl, name) {
      await new Promise((r) => setTimeout(r, 500))
      return {
        name,
        token: 'btk_MOCK_' + Math.random().toString(36).slice(2, 34),
        created: new Date().toISOString(),
      }
    },
    async appSettings() {
      return {
        minimizeToTray: false,
        closeToTray: true,
        floatingMonitorOnMinimize: true,
        openAtLogin: false,
        colorScheme: 'mint' as const,
        uiLocale: 'pl' as const,
        handshakePhrase: mockHandshakePhrase,
        handshakeEnabled: mockHandshakeEnabled,
        autoCheckpointEnabled: mockAutoCheckpointEnabled,
      }
    },
    async appSettingsSet(patch) {
      if (typeof patch.handshakePhrase === 'string' && patch.handshakePhrase.trim()) {
        mockHandshakePhrase = patch.handshakePhrase.trim()
      }
      if (typeof patch.handshakeEnabled === 'boolean') {
        mockHandshakeEnabled = patch.handshakeEnabled
      }
      if (typeof patch.autoCheckpointEnabled === 'boolean') {
        mockAutoCheckpointEnabled = patch.autoCheckpointEnabled
      }
      return {
        minimizeToTray: patch.minimizeToTray ?? false,
        closeToTray: patch.closeToTray ?? true,
        floatingMonitorOnMinimize: patch.floatingMonitorOnMinimize ?? true,
        openAtLogin: patch.openAtLogin ?? false,
        colorScheme: patch.colorScheme ?? 'mint',
        uiLocale: patch.uiLocale ?? 'pl',
        onboarded: patch.onboarded,
        handshakePhrase: mockHandshakePhrase,
        handshakeEnabled: mockHandshakeEnabled,
        autoCheckpointEnabled: mockAutoCheckpointEnabled,
      }
    },
    onColorScheme(_cb) {
      return () => {}
    },
    onUiLocale(_cb) {
      return () => {}
    },
    async openLogs() {
      return '/mock/logs'
    },
    async appVersion() {
      return { version: '0.1.8', identity: '0.1.8 · mock · 1970-01-01 00:00' }
    },
    async floatingMonitorHide() {
      return { visible: false }
    },
    async floatingMonitorOpenMain() {
      return { ok: true }
    },
    async floatingMonitorGetAlwaysOnTop() {
      return { alwaysOnTop: true }
    },
    async floatingMonitorSetAlwaysOnTop(on) {
      return { alwaysOnTop: on }
    },
    onHandshakePhrase() {
      return () => {}
    },
    async profilePreviewShow() {
      return { visible: true }
    },
    async profilePreviewHide() {
      return { visible: false }
    },
    async profilePreviewLoad() {
      return {
        status: 'ok' as const,
        summary:
          'To jest przykładowy podgląd profilu (tryb przeglądarki). Nic nie zostało zapisane.',
        source: 'fallback' as const,
        userMd: '§ PROFIL\nPrzykładowy profil (browser mock).\n',
      }
    },
    onProfilePreviewProgress() {
      return () => {}
    },
    async profilePreviewSave(_content: string) {
      return { ok: true as const, path: 'mock/USER.md', chars: _content.length }
    },
    onAppToast() {
      return () => {}
    },
    onAppNavigate() {
      return () => {}
    },
    minimize() {},
    toggleMaximize() {},
    close() {}
  }
}

export const api: PomniaBridge =
  typeof window !== 'undefined' && (window as any).pomnia
    ? ((window as any).pomnia as PomniaBridge)
    : mockBridge()

export const isMock = api.platform === 'browser'
